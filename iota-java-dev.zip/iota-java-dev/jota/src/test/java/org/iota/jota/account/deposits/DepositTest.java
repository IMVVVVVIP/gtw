package org.iota.jota.account.deposits;

import org.iota.jota.types.Hash;

public abstract class DepositTest {

    protected static final Hash depositAddress = 
            new Hash("LXQHWNY9CQOHPNMKFJFIJHGEPAENAOVFRDIBF99PPHDTWJDCGHLYETXT9NPUVSNKT9XDTDYNJKJCPQMZCJHDUIME9G");
}
