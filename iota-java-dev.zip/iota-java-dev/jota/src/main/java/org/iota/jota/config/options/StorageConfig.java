package org.iota.jota.config.options;

/**
 * 
 * Configuration container for all storage methods
 *
 */
public interface StorageConfig {
    
}
