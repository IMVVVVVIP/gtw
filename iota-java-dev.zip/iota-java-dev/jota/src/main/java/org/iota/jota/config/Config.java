package org.iota.jota.config;

public interface Config {

    //TODO getSource() ?
}
