package org.iota.jota.types;

public class Seed {

}
