package org.iota.jota.account.event;

public interface Event {

}
