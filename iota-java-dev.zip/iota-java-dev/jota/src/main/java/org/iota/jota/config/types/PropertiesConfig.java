package org.iota.jota.config.types;

import org.iota.jota.store.PropertiesStore;

public class PropertiesConfig extends FileConfig {

    public PropertiesConfig(PropertiesStore store) throws Exception{
        super(store);
    }

}
