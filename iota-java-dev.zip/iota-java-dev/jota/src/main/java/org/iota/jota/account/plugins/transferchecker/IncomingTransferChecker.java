package org.iota.jota.account.plugins.transferchecker;

public interface IncomingTransferChecker extends TransferChecker {

}
