package org.iota.jota.account.plugins.transferchecker;

public interface TransferChecker{

}
