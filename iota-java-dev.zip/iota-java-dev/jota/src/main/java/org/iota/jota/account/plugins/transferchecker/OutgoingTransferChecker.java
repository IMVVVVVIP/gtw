package org.iota.jota.account.plugins.transferchecker;

public interface OutgoingTransferChecker extends TransferChecker {

}
