package org.iota.jota.account.condition;

public interface ExpireCondition {

}
