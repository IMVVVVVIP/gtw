package org.iota.jota.pow;

import org.iota.jota.IotaPoW;

public interface IotaLocalPoW extends IotaPoW {

}
